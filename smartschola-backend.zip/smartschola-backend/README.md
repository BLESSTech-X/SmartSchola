# Smart Schola API — Backend

## Quick Start (Windows Command Prompt)

```cmd
cd smartschola-backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```
Edit `.env` in Notepad — set your `SECRET_KEY` to a long random string.

```cmd
python init_db.py
python -m uvicorn main:app --reload --port 8000
```

Open: http://localhost:8000/docs

**Login:** admin / schola2024  ← CHANGE THIS PASSWORD IMMEDIATELY

---

## Test All Endpoints (Command Prompt)

### 1. Login (get token)
```cmd
curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json" -d "{\"username\":\"admin\",\"password\":\"schola2024\"}"
```
Copy the `access_token` from the response. Use it as `TOKEN` below.

### 2. Get dashboard stats
```cmd
curl http://localhost:8000/dashboard/stats -H "Authorization: Bearer TOKEN"
```

### 3. Add a student
```cmd
curl -X POST http://localhost:8000/students -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"first_name\":\"Chanda\",\"last_name\":\"Mutale\",\"grade\":7,\"class_name\":\"7A\",\"gender\":\"Female\",\"parent_phone\":\"+260971234567\"}"
```

### 4. List students
```cmd
curl http://localhost:8000/students -H "Authorization: Bearer TOKEN"
```

### 5. Add a subject
```cmd
curl -X POST http://localhost:8000/subjects -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"name\":\"Mathematics\",\"code\":\"MATH\"}"
```

### 6. Enter bulk marks (replace student_id and subject_id with real IDs)
```cmd
curl -X POST http://localhost:8000/marks/bulk -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"marks\":[{\"student_id\":1,\"subject_id\":1,\"term\":1,\"year\":2025,\"score\":78}]}"
```

### 7. Get student marks
```cmd
curl http://localhost:8000/marks/1 -H "Authorization: Bearer TOKEN"
```

### 8. Add fee record
```cmd
curl -X POST http://localhost:8000/fees -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"student_id\":1,\"term\":1,\"year\":2025,\"amount_due\":1500.00,\"amount_paid\":750.00,\"payment_method\":\"MoMo\"}"
```

### 9. Get fees summary
```cmd
curl http://localhost:8000/fees/summary -H "Authorization: Bearer TOKEN"
```

### 10. Send fee reminders
```cmd
curl -X POST http://localhost:8000/fees/send-reminders -H "Authorization: Bearer TOKEN"
```

### 11. Send SMS
```cmd
curl -X POST http://localhost:8000/sms/send -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"recipients\":\"all_parents\",\"message\":\"School fees reminder from Smart Schola.\"}"
```

### 12. Download student PDF report (save to file)
```cmd
curl http://localhost:8000/reports/student/1/pdf?term=1&year=2025 -H "Authorization: Bearer TOKEN" --output report.pdf
```

### 13. Update school settings
```cmd
curl -X PUT http://localhost:8000/settings -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"name\":\"Chawama Basic School\",\"address\":\"Chawama, Lusaka\",\"headmaster_name\":\"Mr. Banda\"}"
```

### 14. Get subjects
```cmd
curl http://localhost:8000/subjects
```

### 15. Change password
```cmd
curl -X POST http://localhost:8000/auth/change-password -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"current_password\":\"schola2024\",\"new_password\":\"MyNewPass123\",\"confirm_password\":\"MyNewPass123\"}"
```

---

## Deploy to Vercel

### Step 1 — Get free PostgreSQL database
Go to https://supabase.com → New project → Settings → Database → Connection string (URI)
Copy the string (looks like: `postgresql://postgres:password@db.xxx.supabase.co:5432/postgres`)

### Step 2 — Deploy
```cmd
npm install -g vercel
vercel login
cd smartschola-backend
vercel --prod
```

### Step 3 — Set environment variables
```cmd
vercel env add DATABASE_URL
vercel env add SECRET_KEY
vercel env add FRONTEND_URL
vercel --prod
```

Set `FRONTEND_URL` to your frontend Vercel URL (e.g. `https://smartschola.vercel.app`)

### Step 4 — Initialize DB on Vercel
Visit: `https://your-backend.vercel.app/docs`  
Run the `/auth/login` endpoint with admin/schola2024 to confirm it works.

---

## Connect Frontend to Backend
In your frontend Vercel dashboard → Settings → Environment Variables:
```
VITE_API_URL = https://your-backend.vercel.app
```
Redeploy frontend.

---

## First Time Setup
1. Login: admin / schola2024
2. Settings → Enter school name, address, headmaster
3. Settings → Add subjects (Mathematics, English, Science, etc.)
4. Students → Add your students
5. Mark Entry → Enter marks
6. You're live!

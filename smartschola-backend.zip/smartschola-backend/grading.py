"""
Smart Schola - ECZ Grading Engine + AI Remark Generator
"""
from typing import Optional
from sqlalchemy.orm import Session


def get_ecz_grade(score: int) -> int:
    if score >= 80: return 1
    elif score >= 70: return 2
    elif score >= 60: return 3
    elif score >= 50: return 4
    elif score >= 40: return 5
    elif score >= 30: return 6
    elif score >= 20: return 7
    elif score >= 10: return 8
    else: return 9


def get_division(aggregate: int) -> str:
    """aggregate = sum of best 5 ECZ grades"""
    if aggregate <= 12: return "Division I"
    elif aggregate <= 19: return "Division II"
    elif aggregate <= 25: return "Division III"
    elif aggregate <= 32: return "Division IV"
    else: return "Fail"


def get_class_position(student_id: int, class_name: str, term: int, year: int, db: Session) -> dict:
    """Returns position and total students in class"""
    import models
    # Get all students in the class
    students_in_class = db.query(models.Student).filter(
        models.Student.class_name == class_name,
        models.Student.is_active == True
    ).all()

    student_totals = []
    for s in students_in_class:
        marks = db.query(models.Mark).filter(
            models.Mark.student_id == s.id,
            models.Mark.term == term,
            models.Mark.year == year
        ).all()
        total = sum(m.score for m in marks)
        student_totals.append((s.id, total))

    student_totals.sort(key=lambda x: x[1], reverse=True)
    total_students = len(student_totals)

    for pos, (sid, _) in enumerate(student_totals, 1):
        if sid == student_id:
            return {"position": pos, "total": total_students}

    return {"position": 0, "total": total_students}


def generate_remark(score: int, subject_name: str) -> str:
    if score >= 80:
        return f"Excellent performance in {subject_name}. Keep up the outstanding work."
    elif score >= 70:
        return f"Very good performance in {subject_name}. Continue with this strong effort."
    elif score >= 60:
        return f"Good performance in {subject_name}. Focus on consistency to reach the top."
    elif score >= 50:
        return f"Satisfactory performance in {subject_name}. More practice will yield better results."
    elif score >= 40:
        return f"Adequate performance in {subject_name}. Increased effort and revision is needed."
    elif score >= 30:
        return f"Below average in {subject_name}. Regular revision and teacher support is recommended."
    else:
        return f"Poor performance in {subject_name}. Urgent intervention and extra lessons are required."


def check_anomaly(score: int, student_id: int, subject_id: int, db: Session) -> bool:
    """Flag if score is 25+ points above/below student's average for this subject"""
    import models
    past_marks = db.query(models.Mark).filter(
        models.Mark.student_id == student_id,
        models.Mark.subject_id == subject_id
    ).order_by(models.Mark.created_at.desc()).limit(3).all()

    if len(past_marks) < 2:
        return False

    avg = sum(m.score for m in past_marks) / len(past_marks)
    return abs(score - avg) > 25


def get_aggregate_and_division(student_id: int, term: int, year: int, db: Session) -> dict:
    """Calculate best 5 subjects aggregate and division"""
    import models
    marks = db.query(models.Mark).filter(
        models.Mark.student_id == student_id,
        models.Mark.term == term,
        models.Mark.year == year
    ).all()

    if not marks:
        return {"aggregate": 0, "division": "N/A", "total_score": 0}

    # Sort by ECZ grade (lower is better), take best 5
    sorted_marks = sorted(marks, key=lambda m: m.ecz_grade)
    best_5 = sorted_marks[:5]
    aggregate = sum(m.ecz_grade for m in best_5)
    total_score = sum(m.score for m in marks)

    return {
        "aggregate": aggregate,
        "division": get_division(aggregate),
        "total_score": total_score
    }

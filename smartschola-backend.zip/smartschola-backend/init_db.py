"""
Smart Schola - Database Initialization
Run once to create tables and first admin user.
"""
import sys
from database import engine, Base, SessionLocal
from auth import get_password_hash
import models

def init():
    print("Creating database tables...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    existing = db.query(models.User).filter(models.User.username == "admin").first()
    if existing:
        print("Admin user already exists. Database is ready.")
        db.close()
        return

    admin = models.User(
        username="admin",
        full_name="Administrator",
        role="admin",
        hashed_password=get_password_hash("schola2024"),
        is_active=True
    )
    db.add(admin)
    db.commit()
    db.close()

    print("\n" + "="*50)
    print("  Smart Schola Database Initialized!")
    print("="*50)
    print("\n  Login credentials:")
    print("  Username : admin")
    print("  Password : schola2024")
    print("\n  ⚠  CHANGE YOUR PASSWORD AFTER FIRST LOGIN!")
    print("="*50 + "\n")

if __name__ == "__main__":
    init()

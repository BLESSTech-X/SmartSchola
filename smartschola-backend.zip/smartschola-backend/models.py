"""
Smart Schola - SQLAlchemy ORM Models
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from database import Base


class School(Base):
    __tablename__ = "schools"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), default="")
    address = Column(String(500), default="")
    headmaster_name = Column(String(255), default="")
    phone = Column(String(50), default="")
    email = Column(String(255), default="")
    sms_provider = Column(String(50), default="africas_talking")
    sms_api_key = Column(String(500), default="")
    sms_username = Column(String(255), default="")
    sms_sender_id = Column(String(50), default="SmartSchola")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(20), default="teacher")  # admin, teacher, viewer
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    marks = relationship("Mark", back_populates="entered_by_user")
    activity_logs = relationship("ActivityLog", back_populates="user")


class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    grade = Column(Integer, nullable=False)
    class_name = Column(String(20), nullable=False)
    date_of_birth = Column(String(20), nullable=True)
    gender = Column(String(10), nullable=True)
    parent_phone = Column(String(30), nullable=True)
    address = Column(String(500), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    marks = relationship("Mark", back_populates="student")
    fees = relationship("Fee", back_populates="student")


class Subject(Base):
    __tablename__ = "subjects"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    code = Column(String(20), nullable=False)
    grade_level = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    marks = relationship("Mark", back_populates="subject")


class Mark(Base):
    __tablename__ = "marks"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    term = Column(Integer, nullable=False)
    year = Column(Integer, nullable=False)
    score = Column(Integer, nullable=False)
    ecz_grade = Column(Integer, nullable=False)
    division_contribution = Column(Integer, nullable=True)
    ai_remark = Column(Text, nullable=True)
    verify_required = Column(Boolean, default=False)
    entered_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    student = relationship("Student", back_populates="marks")
    subject = relationship("Subject", back_populates="marks")
    entered_by_user = relationship("User", back_populates="marks")


class Fee(Base):
    __tablename__ = "fees"
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    term = Column(Integer, nullable=False)
    year = Column(Integer, nullable=False)
    amount_due = Column(Float, nullable=False, default=0.0)
    amount_paid = Column(Float, nullable=False, default=0.0)
    balance = Column(Float, nullable=False, default=0.0)
    payment_date = Column(String(30), nullable=True)
    payment_method = Column(String(30), default="Cash")
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    student = relationship("Student", back_populates="fees")


class SMSLog(Base):
    __tablename__ = "sms_logs"
    id = Column(Integer, primary_key=True, index=True)
    recipient_phone = Column(String(30), nullable=False)
    recipient_name = Column(String(255), nullable=True)
    message = Column(Text, nullable=False)
    provider = Column(String(50), nullable=True)
    status = Column(String(20), default="pending")
    sent_at = Column(DateTime, default=datetime.utcnow)
    delivered_at = Column(DateTime, nullable=True)


class ActivityLog(Base):
    __tablename__ = "activity_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(255), nullable=False)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="activity_logs")

"""
Smart Schola - PDF Report Slip Generator using ReportLab
"""
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas
from datetime import datetime

NAVY = colors.HexColor("#0B1D3A")
GOLD = colors.HexColor("#F5A623")
LIGHT_GRAY = colors.HexColor("#F8F9FA")
MID_GRAY = colors.HexColor("#6C757D")


def generate_student_report(student, marks_data, school, position_info, term, year) -> BytesIO:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=2*cm,
        leftMargin=2*cm,
        topMargin=2*cm,
        bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    school_name = school.name if school and school.name else "Smart Schola School"
    school_address = school.address if school and school.address else ""
    headmaster = school.headmaster_name if school and school.headmaster_name else ""
    school_phone = school.phone if school and school.phone else ""

    header_style = ParagraphStyle('header', fontSize=18, fontName='Helvetica-Bold',
                                   textColor=NAVY, alignment=TA_CENTER, spaceAfter=4)
    sub_header_style = ParagraphStyle('subheader', fontSize=10, fontName='Helvetica',
                                       textColor=MID_GRAY, alignment=TA_CENTER, spaceAfter=2)
    title_style = ParagraphStyle('title', fontSize=14, fontName='Helvetica-Bold',
                                  textColor=GOLD, alignment=TA_CENTER, spaceAfter=8)

    story.append(Paragraph(school_name.upper(), header_style))
    if school_address:
        story.append(Paragraph(school_address, sub_header_style))
    if headmaster or school_phone:
        story.append(Paragraph(f"Headmaster: {headmaster}   |   Tel: {school_phone}", sub_header_style))

    story.append(HRFlowable(width="100%", thickness=3, color=GOLD, spaceAfter=8))
    story.append(Paragraph("STUDENT ACADEMIC REPORT SLIP", title_style))
    story.append(HRFlowable(width="100%", thickness=1, color=NAVY, spaceAfter=12))

    # ── Student Info ──────────────────────────────────────────────────────────
    full_name = f"{student.first_name} {student.last_name}"
    info_data = [
        ["Student Name:", full_name, "Grade:", f"Grade {student.grade}"],
        ["Class:", student.class_name, "Term:", f"Term {term}"],
        ["Academic Year:", str(year), "Gender:", student.gender or "—"],
    ]
    info_table = Table(info_data, colWidths=[3.5*cm, 6*cm, 2.5*cm, 5*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (0, 0), (0, -1), NAVY),
        ('TEXTCOLOR', (2, 0), (2, -1), NAVY),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 12))

    # ── Marks Table ───────────────────────────────────────────────────────────
    table_data = [["#", "SUBJECT", "MARKS (100)", "ECZ GRADE", "REMARKS"]]
    total_score = 0

    for i, mark in enumerate(marks_data, 1):
        grade = mark.get("ecz_grade", 9)
        score = mark.get("score", 0)
        total_score += score
        remark = mark.get("ai_remark", "")
        if len(remark) > 50:
            remark = remark[:50] + "..."
        table_data.append([
            str(i),
            mark.get("subject_name", ""),
            str(score),
            str(grade),
            remark
        ])

    marks_table = Table(table_data, colWidths=[1*cm, 5.5*cm, 3*cm, 2.5*cm, 5*cm])
    marks_table.setStyle(TableStyle([
        # Header row
        ('BACKGROUND', (0, 0), (-1, 0), NAVY),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        # Data rows
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 1), (0, -1), 'CENTER'),
        ('ALIGN', (2, 1), (3, -1), 'CENTER'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#DEE2E6")),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(marks_table)
    story.append(Spacer(1, 14))

    # ── Summary ───────────────────────────────────────────────────────────────
    aggregate = sum(m.get("ecz_grade", 9) for m in sorted(marks_data, key=lambda x: x.get("ecz_grade", 9))[:5])
    from grading import get_division
    division = get_division(aggregate)
    pos = position_info.get("position", 0)
    total_students = position_info.get("total", 0)
    pos_str = f"{pos} out of {total_students}" if pos > 0 else "N/A"

    summary_data = [
        ["Total Marks:", str(total_score), "Division:", division],
        ["Aggregate (Best 5):", str(aggregate), "Class Position:", pos_str],
    ]
    summary_table = Table(summary_data, colWidths=[4*cm, 4*cm, 3.5*cm, 5.5*cm])
    summary_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (0, 0), (0, -1), NAVY),
        ('TEXTCOLOR', (2, 0), (2, -1), NAVY),
        ('BACKGROUND', (0, 0), (-1, -1), LIGHT_GRAY),
        ('BOX', (0, 0), (-1, -1), 1, GOLD),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 16))

    # ── Remarks + Signature ───────────────────────────────────────────────────
    remark_style = ParagraphStyle('remark', fontSize=9, fontName='Helvetica', leading=14)
    label_style = ParagraphStyle('label', fontSize=10, fontName='Helvetica-Bold', textColor=NAVY)

    story.append(Paragraph("Class Teacher's Remarks:", label_style))
    story.append(Paragraph("_" * 90, remark_style))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Headmaster's Remarks:", label_style))
    story.append(Paragraph("_" * 90, remark_style))
    story.append(Spacer(1, 20))

    sig_data = [
        ["Class Teacher: ___________________", "Headmaster: ___________________", f"Date: {datetime.now().strftime('%d/%m/%Y')}"]
    ]
    sig_table = Table(sig_data, colWidths=[6.5*cm, 6.5*cm, 4*cm])
    sig_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
    ]))
    story.append(sig_table)

    story.append(HRFlowable(width="100%", thickness=1, color=GOLD, spaceBefore=16))
    footer_style = ParagraphStyle('footer', fontSize=8, fontName='Helvetica',
                                   textColor=MID_GRAY, alignment=TA_CENTER)
    story.append(Paragraph("Smart Schola — Empowering Zambian Schools Through Technology", footer_style))

    doc.build(story)
    buffer.seek(0)
    return buffer


def generate_class_report(students_marks, school, class_name, term, year) -> BytesIO:
    """Generate a full class report PDF"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=1.5*cm, leftMargin=1.5*cm,
                             topMargin=1.5*cm, bottomMargin=1.5*cm)
    styles = getSampleStyleSheet()
    story = []

    school_name = school.name if school and school.name else "Smart Schola School"
    header_style = ParagraphStyle('header', fontSize=16, fontName='Helvetica-Bold',
                                   textColor=NAVY, alignment=TA_CENTER)
    story.append(Paragraph(school_name.upper(), header_style))
    story.append(Paragraph(f"CLASS RESULTS — {class_name} | Term {term} | {year}", header_style))
    story.append(HRFlowable(width="100%", thickness=2, color=GOLD, spaceAfter=12))

    table_data = [["#", "Student Name", "Total Score", "Division", "Position"]]
    for i, item in enumerate(students_marks, 1):
        table_data.append([
            str(i),
            item.get("student_name", ""),
            str(item.get("total_score", 0)),
            item.get("division", "N/A"),
            str(item.get("position", "N/A"))
        ])

    t = Table(table_data, colWidths=[1*cm, 7*cm, 3.5*cm, 3.5*cm, 2*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#DEE2E6")),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(t)

    footer_style = ParagraphStyle('footer', fontSize=8, fontName='Helvetica',
                                   textColor=MID_GRAY, alignment=TA_CENTER)
    story.append(Spacer(1, 20))
    story.append(Paragraph("Smart Schola — Empowering Zambian Schools Through Technology", footer_style))

    doc.build(story)
    buffer.seek(0)
    return buffer

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import datetime, date
from database import get_db
from auth import get_current_user
import models, schemas

router = APIRouter()

@router.get("/stats", response_model=schemas.DashboardStats)
def get_stats(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    total_students = db.query(models.Student).filter(models.Student.is_active == True).count()

    current_year = datetime.utcnow().year
    fees = db.query(models.Fee).filter(models.Fee.year == current_year).all()
    fees_collected = sum(f.amount_paid for f in fees)
    fees_outstanding = sum(f.balance for f in fees if f.balance > 0)

    today = date.today()
    sms_today = db.query(models.SMSLog).filter(
        models.SMSLog.sent_at >= datetime.combine(today, datetime.min.time())
    ).count()

    recent = db.query(models.ActivityLog).order_by(models.ActivityLog.created_at.desc()).limit(10).all()

    return schemas.DashboardStats(
        total_students=total_students,
        fees_collected=fees_collected,
        fees_outstanding=fees_outstanding,
        sms_sent_today=sms_today,
        recent_activity=[schemas.ActivityItem.model_validate(a) for a in recent]
    )

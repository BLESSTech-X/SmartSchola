from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from auth import get_current_user, log_activity
from sms_service import send_sms
import models, schemas

router = APIRouter()

def fee_status(amount_due, amount_paid):
    if amount_paid <= 0: return "Unpaid"
    if amount_paid >= amount_due: return "Paid"
    return "Partial"

def build_fee_response(f):
    fr = schemas.FeeResponse.model_validate(f)
    fr.student_name = f"{f.student.first_name} {f.student.last_name}" if f.student else ""
    fr.grade = f.student.grade if f.student else 0
    fr.status = fee_status(f.amount_due, f.amount_paid)
    return fr

@router.get("", response_model=schemas.FeeListResponse)
def list_fees(
    term: Optional[int] = None,
    year: Optional[int] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    per_page: int = 20,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    q = db.query(models.Fee).join(models.Student)
    if term: q = q.filter(models.Fee.term == term)
    if year: q = q.filter(models.Fee.year == year)
    if search:
        q = q.filter((models.Student.first_name + " " + models.Student.last_name).ilike(f"%{search}%"))

    all_fees = q.all()
    if status:
        all_fees = [f for f in all_fees if fee_status(f.amount_due, f.amount_paid) == status]

    total = len(all_fees)
    paginated = all_fees[(page-1)*per_page : page*per_page]

    total_due = sum(f.amount_due for f in all_fees)
    total_collected = sum(f.amount_paid for f in all_fees)
    outstanding = sum(f.balance for f in all_fees if f.balance > 0)
    student_ids = set(f.student_id for f in all_fees)

    summary = schemas.FeeSummary(
        total_due=total_due,
        total_collected=total_collected,
        outstanding=outstanding,
        student_count=len(student_ids)
    )

    return {"fees": [build_fee_response(f) for f in paginated], "total": total, "summary": summary}

@router.post("", response_model=schemas.FeeResponse)
def create_fee(data: schemas.FeeCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    student = db.query(models.Student).filter(models.Student.id == data.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    balance = data.amount_due - data.amount_paid
    fee = models.Fee(**data.model_dump(), balance=balance)
    db.add(fee)
    db.commit()
    db.refresh(fee)
    log_activity(db, current_user.id, f"Fee record created for {student.first_name} {student.last_name}")
    return build_fee_response(fee)

@router.put("/{fee_id}", response_model=schemas.FeeResponse)
def update_fee(fee_id: int, data: schemas.FeeUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    fee = db.query(models.Fee).filter(models.Fee.id == fee_id).first()
    if not fee:
        raise HTTPException(status_code=404, detail="Fee not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(fee, k, v)
    fee.balance = fee.amount_due - fee.amount_paid
    db.commit()
    db.refresh(fee)
    log_activity(db, current_user.id, f"Fee record updated")
    return build_fee_response(fee)

@router.delete("/{fee_id}")
def delete_fee(fee_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    fee = db.query(models.Fee).filter(models.Fee.id == fee_id).first()
    if not fee:
        raise HTTPException(status_code=404, detail="Fee not found")
    db.delete(fee)
    db.commit()
    return {"message": "Fee record deleted"}

@router.get("/summary", response_model=schemas.FeeSummary)
def get_summary(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    fees = db.query(models.Fee).all()
    return schemas.FeeSummary(
        total_due=sum(f.amount_due for f in fees),
        total_collected=sum(f.amount_paid for f in fees),
        outstanding=sum(f.balance for f in fees if f.balance > 0),
        student_count=len(set(f.student_id for f in fees))
    )

@router.post("/send-reminders")
def send_reminders(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    school = db.query(models.School).first()
    settings_dict = {}
    if school:
        settings_dict = {"sms_provider": school.sms_provider, "sms_api_key": school.sms_api_key,
                         "sms_username": school.sms_username, "sms_sender_id": school.sms_sender_id}

    fees_with_balance = db.query(models.Fee).filter(models.Fee.balance > 0).all()
    sent = 0
    failed = 0
    seen_students = set()

    for fee in fees_with_balance:
        student = fee.student
        if not student or not student.parent_phone or student.id in seen_students:
            continue
        seen_students.add(student.id)
        message = f"Dear Parent, {student.first_name} {student.last_name} has an outstanding fee balance of K{fee.balance:.2f}. Please settle at the earliest. - Smart Schola"
        result = send_sms(student.parent_phone, message, settings_dict)
        status = result.get("status", "failed")
        log_entry = models.SMSLog(
            recipient_phone=student.parent_phone,
            recipient_name=f"{student.first_name} {student.last_name}",
            message=message, provider=settings_dict.get("sms_provider", ""),
            status="delivered" if status in ("delivered","logged") else "failed"
        )
        db.add(log_entry)
        if status in ("delivered", "logged"): sent += 1
        else: failed += 1

    db.commit()
    log_activity(db, current_user.id, f"Fee reminders sent: {sent} delivered, {failed} failed")
    return {"sent": sent, "failed": failed}

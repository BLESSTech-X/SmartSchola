from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from auth import get_current_user, log_activity
from grading import get_ecz_grade, generate_remark, check_anomaly
import models, schemas

router = APIRouter()

@router.post("/bulk", response_model=schemas.BulkMarkResponse)
def bulk_save_marks(data: schemas.BulkMarkCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    saved = 0
    updated = 0
    flagged = []

    for m in data.marks:
        student = db.query(models.Student).filter(models.Student.id == m.student_id, models.Student.is_active == True).first()
        subject = db.query(models.Subject).filter(models.Subject.id == m.subject_id).first()
        if not student or not subject:
            continue

        ecz_grade = get_ecz_grade(m.score)
        remark = generate_remark(m.score, subject.name)
        anomaly = check_anomaly(m.score, m.student_id, m.subject_id, db)

        if anomaly:
            flagged.append(f"{student.first_name} {student.last_name}")

        existing = db.query(models.Mark).filter(
            models.Mark.student_id == m.student_id,
            models.Mark.subject_id == m.subject_id,
            models.Mark.term == m.term,
            models.Mark.year == m.year
        ).first()

        if existing:
            existing.score = m.score
            existing.ecz_grade = ecz_grade
            existing.ai_remark = remark
            existing.verify_required = anomaly
            existing.entered_by = current_user.id
            updated += 1
        else:
            mark = models.Mark(
                student_id=m.student_id, subject_id=m.subject_id,
                term=m.term, year=m.year, score=m.score,
                ecz_grade=ecz_grade, ai_remark=remark,
                verify_required=anomaly, entered_by=current_user.id
            )
            db.add(mark)
            saved += 1

    db.commit()
    log_activity(db, current_user.id, f"Bulk marks entry: {saved} saved, {updated} updated")
    return {"saved": saved, "updated": updated, "flagged": flagged}

@router.get("/{student_id}")
def get_student_marks(
    student_id: int,
    term: Optional[int] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    q = db.query(models.Mark).filter(models.Mark.student_id == student_id)
    if term: q = q.filter(models.Mark.term == term)
    if year: q = q.filter(models.Mark.year == year)
    marks = q.all()
    result = []
    for m in marks:
        mr = schemas.MarkResponse.model_validate(m)
        mr.student_name = f"{m.student.first_name} {m.student.last_name}" if m.student else ""
        mr.subject_name = m.subject.name if m.subject else ""
        result.append(mr)
    return result

@router.get("/class/{class_name}")
def get_class_marks(
    class_name: str,
    subject_id: Optional[int] = None,
    term: Optional[int] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    students = db.query(models.Student).filter(models.Student.class_name == class_name, models.Student.is_active == True).all()
    result = []
    for s in students:
        q = db.query(models.Mark).filter(models.Mark.student_id == s.id)
        if subject_id: q = q.filter(models.Mark.subject_id == subject_id)
        if term: q = q.filter(models.Mark.term == term)
        if year: q = q.filter(models.Mark.year == year)
        marks = q.all()
        result.append({
            "student_id": s.id,
            "student_name": f"{s.first_name} {s.last_name}",
            "marks": [{"subject_name": m.subject.name if m.subject else "", "score": m.score, "ecz_grade": m.ecz_grade} for m in marks]
        })
    return result

@router.delete("/{mark_id}")
def delete_mark(mark_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    mark = db.query(models.Mark).filter(models.Mark.id == mark_id).first()
    if not mark:
        raise HTTPException(status_code=404, detail="Mark not found")
    db.delete(mark)
    db.commit()
    return {"message": "Mark deleted"}

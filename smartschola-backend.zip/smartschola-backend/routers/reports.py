from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from auth import get_current_user
from grading import get_aggregate_and_division, get_class_position
from pdf_generator import generate_student_report, generate_class_report
import models

router = APIRouter()

@router.get("/student/{student_id}/pdf")
def student_report_pdf(
    student_id: int,
    term: int = Query(...),
    year: int = Query(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    student = db.query(models.Student).filter(models.Student.id == student_id, models.Student.is_active == True).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    marks = db.query(models.Mark).filter(
        models.Mark.student_id == student_id,
        models.Mark.term == term,
        models.Mark.year == year
    ).all()

    marks_data = []
    for m in marks:
        marks_data.append({
            "subject_name": m.subject.name if m.subject else "",
            "score": m.score,
            "ecz_grade": m.ecz_grade,
            "ai_remark": m.ai_remark or ""
        })

    school = db.query(models.School).first()
    position_info = get_class_position(student_id, student.class_name, term, year, db)

    buffer = generate_student_report(student, marks_data, school, position_info, term, year)
    filename = f"report_{student.first_name}_{student.last_name}_T{term}_{year}.pdf"

    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@router.get("/class/{class_name}/pdf")
def class_report_pdf(
    class_name: str,
    term: int = Query(...),
    year: int = Query(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    students = db.query(models.Student).filter(
        models.Student.class_name == class_name,
        models.Student.is_active == True
    ).all()

    if not students:
        raise HTTPException(status_code=404, detail="No students found in this class")

    students_marks = []
    for s in students:
        agg = get_aggregate_and_division(s.id, term, year, db)
        pos = get_class_position(s.id, class_name, term, year, db)
        students_marks.append({
            "student_name": f"{s.first_name} {s.last_name}",
            "total_score": agg["total_score"],
            "division": agg["division"],
            "position": pos["position"]
        })

    students_marks.sort(key=lambda x: x["position"])
    school = db.query(models.School).first()
    buffer = generate_class_report(students_marks, school, class_name, term, year)

    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=class_{class_name}_T{term}_{year}.pdf"}
    )

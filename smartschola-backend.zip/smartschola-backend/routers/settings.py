from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from auth import get_current_user
import models, schemas

router = APIRouter()

@router.get("", response_model=schemas.SchoolSettingsResponse)
def get_settings(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    school = db.query(models.School).first()
    if not school:
        return schemas.SchoolSettingsResponse()
    return schemas.SchoolSettingsResponse.model_validate(school)

@router.put("", response_model=schemas.SchoolSettingsResponse)
def update_settings(data: schemas.SchoolSettingsUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    school = db.query(models.School).first()
    if not school:
        school = models.School()
        db.add(school)
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(school, k, v)
    db.commit()
    db.refresh(school)
    return schemas.SchoolSettingsResponse.model_validate(school)

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from database import get_db
from auth import get_current_user, log_activity
from sms_service import send_sms
import models, schemas

router = APIRouter()

@router.post("/send", response_model=schemas.SMSResponse)
def send_sms_endpoint(data: schemas.SMSSend, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    school = db.query(models.School).first()
    settings_dict = {}
    if school:
        settings_dict = {"sms_provider": school.sms_provider, "sms_api_key": school.sms_api_key,
                         "sms_username": school.sms_username, "sms_sender_id": school.sms_sender_id}

    # Resolve recipients
    recipients = []
    if data.recipients == "all_parents":
        students = db.query(models.Student).filter(models.Student.is_active == True, models.Student.parent_phone != None).all()
        recipients = [(s.parent_phone, f"{s.first_name} {s.last_name}") for s in students if s.parent_phone]
    elif data.recipients == "fee_defaulters":
        fees = db.query(models.Fee).filter(models.Fee.balance > 0).all()
        seen = set()
        for f in fees:
            if f.student and f.student.parent_phone and f.student_id not in seen:
                seen.add(f.student_id)
                recipients.append((f.student.parent_phone, f"{f.student.first_name} {f.student.last_name}"))
    elif data.recipients.startswith("class_"):
        class_name = data.recipients[6:]
        students = db.query(models.Student).filter(models.Student.class_name == class_name, models.Student.is_active == True).all()
        recipients = [(s.parent_phone, f"{s.first_name} {s.last_name}") for s in students if s.parent_phone]
    elif data.recipients == "custom" and data.custom_phone:
        recipients = [(data.custom_phone, "Custom")]

    sent = 0
    failed = 0
    log_ids = []

    for phone, name in recipients:
        result = send_sms(phone, data.message, settings_dict)
        status = result.get("status", "failed")
        log_entry = models.SMSLog(
            recipient_phone=phone, recipient_name=name,
            message=data.message, provider=settings_dict.get("sms_provider", ""),
            status="delivered" if status in ("delivered","logged") else "failed"
        )
        db.add(log_entry)
        db.flush()
        log_ids.append(log_entry.id)
        if status in ("delivered", "logged"): sent += 1
        else: failed += 1

    db.commit()
    log_activity(db, current_user.id, f"SMS sent to {sent} recipients")
    return {"sent_count": sent, "failed_count": failed, "log_ids": log_ids}

@router.get("/log")
def get_sms_log(page: int = 1, per_page: int = 20, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    total = db.query(models.SMSLog).count()
    logs = db.query(models.SMSLog).order_by(models.SMSLog.sent_at.desc()).offset((page-1)*per_page).limit(per_page).all()
    return {"logs": [schemas.SMSLogResponse.model_validate(l) for l in logs], "total": total, "page": page, "pages": max(1, -(-total // per_page))}

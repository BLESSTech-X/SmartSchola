from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from auth import get_current_user, log_activity
import models, schemas

router = APIRouter()

@router.get("", response_model=schemas.StudentListResponse)
def list_students(
    search: Optional[str] = None,
    grade: Optional[int] = None,
    class_name: Optional[str] = None,
    page: int = 1,
    per_page: int = 20,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    q = db.query(models.Student).filter(models.Student.is_active == True)
    if search:
        q = q.filter((models.Student.first_name + " " + models.Student.last_name).ilike(f"%{search}%"))
    if grade:
        q = q.filter(models.Student.grade == grade)
    if class_name:
        q = q.filter(models.Student.class_name == class_name)
    total = q.count()
    students = q.offset((page - 1) * per_page).limit(per_page).all()
    result = []
    for s in students:
        sr = schemas.StudentResponse.model_validate(s)
        sr.full_name = f"{s.first_name} {s.last_name}"
        result.append(sr)
    return {"students": result, "total": total, "page": page, "pages": max(1, -(-total // per_page))}

@router.post("", response_model=schemas.StudentResponse)
def create_student(data: schemas.StudentCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    student = models.Student(**data.model_dump())
    db.add(student)
    db.commit()
    db.refresh(student)
    log_activity(db, current_user.id, f"Added student: {student.first_name} {student.last_name}")
    sr = schemas.StudentResponse.model_validate(student)
    sr.full_name = f"{student.first_name} {student.last_name}"
    return sr

@router.get("/{student_id}", response_model=schemas.StudentResponse)
def get_student(student_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    student = db.query(models.Student).filter(models.Student.id == student_id, models.Student.is_active == True).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    sr = schemas.StudentResponse.model_validate(student)
    sr.full_name = f"{student.first_name} {student.last_name}"
    return sr

@router.put("/{student_id}", response_model=schemas.StudentResponse)
def update_student(student_id: int, data: schemas.StudentUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    student = db.query(models.Student).filter(models.Student.id == student_id, models.Student.is_active == True).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(student, k, v)
    db.commit()
    db.refresh(student)
    log_activity(db, current_user.id, f"Updated student: {student.first_name} {student.last_name}")
    sr = schemas.StudentResponse.model_validate(student)
    sr.full_name = f"{student.first_name} {student.last_name}"
    return sr

@router.delete("/{student_id}")
def delete_student(student_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    student.is_active = False
    db.commit()
    log_activity(db, current_user.id, f"Removed student: {student.first_name} {student.last_name}")
    return {"message": "Student removed"}

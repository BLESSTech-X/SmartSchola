from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from auth import get_current_user, log_activity
import models, schemas

router = APIRouter()

@router.get("")
def list_subjects(db: Session = Depends(get_db)):
    subjects = db.query(models.Subject).filter(models.Subject.is_active == True).all()
    return [schemas.SubjectResponse.model_validate(s) for s in subjects]

@router.post("", response_model=schemas.SubjectResponse)
def create_subject(data: schemas.SubjectCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    subject = models.Subject(**data.model_dump())
    db.add(subject)
    db.commit()
    db.refresh(subject)
    log_activity(db, current_user.id, f"Added subject: {subject.name}")
    return schemas.SubjectResponse.model_validate(subject)

@router.delete("/{subject_id}")
def delete_subject(subject_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    subject = db.query(models.Subject).filter(models.Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    subject.is_active = False
    db.commit()
    log_activity(db, current_user.id, f"Removed subject: {subject.name}")
    return {"message": "Subject removed"}

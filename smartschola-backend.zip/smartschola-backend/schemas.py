"""
Smart Schola - Pydantic v2 Schemas
"""
from typing import Optional, List, Any
from datetime import datetime
from pydantic import BaseModel, field_validator


# ── Auth ──────────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class UserInfo(BaseModel):
    id: int
    username: str
    full_name: str
    role: str
    class Config: from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserInfo

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
    confirm_password: str


# ── Students ──────────────────────────────────────────────────────────────────
class StudentCreate(BaseModel):
    first_name: str
    last_name: str
    grade: int
    class_name: str
    date_of_birth: Optional[str] = None
    gender: Optional[str] = None
    parent_phone: Optional[str] = None
    address: Optional[str] = None

class StudentUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    grade: Optional[int] = None
    class_name: Optional[str] = None
    date_of_birth: Optional[str] = None
    gender: Optional[str] = None
    parent_phone: Optional[str] = None
    address: Optional[str] = None

class StudentResponse(BaseModel):
    id: int
    first_name: str
    last_name: str
    full_name: str = ""
    grade: int
    class_name: str
    date_of_birth: Optional[str] = None
    gender: Optional[str] = None
    parent_phone: Optional[str] = None
    address: Optional[str] = None
    is_active: bool
    created_at: datetime
    class Config: from_attributes = True

    @classmethod
    def from_orm_with_fullname(cls, obj):
        data = cls.model_validate(obj)
        data.full_name = f"{obj.first_name} {obj.last_name}"
        return data

class StudentListResponse(BaseModel):
    students: List[StudentResponse]
    total: int
    page: int
    pages: int


# ── Subjects ──────────────────────────────────────────────────────────────────
class SubjectCreate(BaseModel):
    name: str
    code: str
    grade_level: Optional[int] = None

class SubjectResponse(BaseModel):
    id: int
    name: str
    code: str
    grade_level: Optional[int] = None
    is_active: bool
    class Config: from_attributes = True


# ── Marks ────────────────────────────────────────────────────────────────────
class MarkCreate(BaseModel):
    student_id: int
    subject_id: int
    term: int
    year: int
    score: int

    @field_validator('score')
    @classmethod
    def score_range(cls, v):
        if not 0 <= v <= 100:
            raise ValueError('Score must be between 0 and 100')
        return v

class BulkMarkCreate(BaseModel):
    marks: List[MarkCreate]

class MarkResponse(BaseModel):
    id: int
    student_id: int
    subject_id: int
    term: int
    year: int
    score: int
    ecz_grade: int
    ai_remark: Optional[str] = None
    verify_required: bool
    student_name: str = ""
    subject_name: str = ""
    created_at: datetime
    class Config: from_attributes = True

class BulkMarkResponse(BaseModel):
    saved: int
    updated: int
    flagged: List[str]


# ── Fees ─────────────────────────────────────────────────────────────────────
class FeeCreate(BaseModel):
    student_id: int
    term: int
    year: int
    amount_due: float
    amount_paid: float = 0.0
    payment_date: Optional[str] = None
    payment_method: Optional[str] = "Cash"
    notes: Optional[str] = None

class FeeUpdate(BaseModel):
    term: Optional[int] = None
    year: Optional[int] = None
    amount_due: Optional[float] = None
    amount_paid: Optional[float] = None
    payment_date: Optional[str] = None
    payment_method: Optional[str] = None
    notes: Optional[str] = None

class FeeResponse(BaseModel):
    id: int
    student_id: int
    student_name: str = ""
    grade: int = 0
    term: int
    year: int
    amount_due: float
    amount_paid: float
    balance: float
    payment_date: Optional[str] = None
    payment_method: Optional[str] = None
    notes: Optional[str] = None
    status: str = ""
    created_at: datetime
    class Config: from_attributes = True

class FeeSummary(BaseModel):
    total_due: float
    total_collected: float
    outstanding: float
    student_count: int

class FeeListResponse(BaseModel):
    fees: List[FeeResponse]
    total: int
    summary: FeeSummary


# ── SMS ───────────────────────────────────────────────────────────────────────
class SMSSend(BaseModel):
    recipients: str  # all_parents, fee_defaulters, class_NAME, custom
    custom_phone: Optional[str] = None
    message: str

class SMSLogResponse(BaseModel):
    id: int
    recipient_phone: str
    recipient_name: Optional[str] = None
    message: str
    provider: Optional[str] = None
    status: str
    sent_at: datetime
    class Config: from_attributes = True

class SMSResponse(BaseModel):
    sent_count: int
    failed_count: int
    log_ids: List[int]


# ── Dashboard ─────────────────────────────────────────────────────────────────
class ActivityItem(BaseModel):
    id: int
    action: str
    details: Optional[str] = None
    created_at: datetime
    class Config: from_attributes = True

class DashboardStats(BaseModel):
    total_students: int
    fees_collected: float
    fees_outstanding: float
    sms_sent_today: int
    recent_activity: List[ActivityItem]


# ── Settings ──────────────────────────────────────────────────────────────────
class SchoolSettingsUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    headmaster_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    sms_provider: Optional[str] = None
    sms_api_key: Optional[str] = None
    sms_username: Optional[str] = None
    sms_sender_id: Optional[str] = None

class SchoolSettingsResponse(BaseModel):
    id: Optional[int] = None
    name: Optional[str] = None
    address: Optional[str] = None
    headmaster_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    sms_provider: Optional[str] = None
    sms_api_key: Optional[str] = None
    sms_username: Optional[str] = None
    sms_sender_id: Optional[str] = None
    class Config: from_attributes = True

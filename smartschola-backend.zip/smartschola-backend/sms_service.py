"""
Smart Schola - SMS Service
Supports: Africa's Talking (Zambia), Custom gateway, File logging (no key)
"""
import os
import requests
from datetime import datetime
from typing import Optional


def send_sms(phone: str, message: str, settings: dict = None) -> dict:
    timestamp = datetime.utcnow().isoformat()

    # Clean phone number
    phone = phone.strip().replace(" ", "")
    if phone.startswith("0") and len(phone) == 10:
        phone = "+260" + phone[1:]
    elif not phone.startswith("+"):
        phone = "+260" + phone

    provider = os.getenv("SMS_PROVIDER", "")
    api_key = os.getenv("SMS_API_KEY", "")
    username = os.getenv("SMS_USERNAME", "")
    sender_id = os.getenv("SMS_SENDER_ID", "SmartSchola")

    # Use settings override if provided
    if settings:
        provider = settings.get("sms_provider", provider)
        api_key = settings.get("sms_api_key", api_key)
        username = settings.get("sms_username", username)
        sender_id = settings.get("sms_sender_id", sender_id)

    # If no API key — log to file
    if not api_key or api_key in ("your-sms-api-key", ""):
        log_path = "sms_log.txt"
        with open(log_path, "a") as f:
            f.write(f"[{timestamp}] TO: {phone} | MSG: {message}\n")
        return {
            "status": "logged",
            "phone": phone,
            "message": message,
            "timestamp": timestamp,
            "note": "SMS logged to sms_log.txt (no API key configured)"
        }

    # Africa's Talking
    if provider == "africas_talking":
        try:
            response = requests.post(
                "https://api.africastalking.com/version1/messaging",
                headers={
                    "apiKey": api_key,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json"
                },
                data={
                    "username": username,
                    "to": phone,
                    "message": message,
                    "from": sender_id
                },
                timeout=10
            )
            if response.status_code == 201:
                return {"status": "delivered", "phone": phone, "message": message, "timestamp": timestamp}
            else:
                return {"status": "failed", "phone": phone, "message": message, "timestamp": timestamp, "error": response.text}
        except Exception as e:
            return {"status": "failed", "phone": phone, "message": message, "timestamp": timestamp, "error": str(e)}

    # Custom gateway
    elif provider == "custom":
        gateway_url = os.getenv("SMS_GATEWAY_URL", "")
        if not gateway_url:
            return {"status": "failed", "phone": phone, "message": "No gateway URL configured", "timestamp": timestamp}
        try:
            response = requests.post(
                gateway_url,
                json={"to": phone, "message": message, "api_key": api_key},
                timeout=10
            )
            status = "delivered" if response.status_code == 200 else "failed"
            return {"status": status, "phone": phone, "message": message, "timestamp": timestamp}
        except Exception as e:
            return {"status": "failed", "phone": phone, "message": message, "timestamp": timestamp, "error": str(e)}

    # Default fallback - log
    with open("sms_log.txt", "a") as f:
        f.write(f"[{timestamp}] TO: {phone} | MSG: {message}\n")
    return {"status": "logged", "phone": phone, "message": message, "timestamp": timestamp}
